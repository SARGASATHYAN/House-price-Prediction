# House-Price-Prediction-Model-using-Linear-Regression-and-PCA
The House Price prediction model is trained by Linear Regression Model which in order to get more accuracy, uses PCA. 
<h6>This project was developed during my summer internship 2021 at my college KIET Group of Institutions, Ghaziabad. I am a bit busy thes days so can't add Proper readme But soon I will upload Details. Till then if you have queries contact kushagrathisside@gmail.com .</h6>
<h4>For Original dataset, you may search on Kaggle. :)</h4>
